<!-- If you want a new icon - fill in this form. If you want something else, just type it in here :-) -->

## The icon I want is:
<!-- We need these three piece of information -->
* Name: 
* URL: 
* Link to icon: 

<!-- The next bit is helpful to us -->
* Vector version of the logo:
* Official style guide or brand guide: 
